package com.thoughtbend.ps.xmldemos.parser.stax;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

public class CustomerMessageXMLEventAPIParser {

	public static void main(String[] args) {
		
		try (InputStream inputStream = ClassLoader.getSystemResourceAsStream("./customer-msg.xml")) {
			
			XMLInputFactory factory = XMLInputFactory.newFactory();
			factory.setProperty(XMLInputFactory.IS_COALESCING, false);
			XMLEventReader eventReader = factory.createXMLEventReader(inputStream);
			
			boolean inMessageElement = false;
			List<String> customerMessages = new ArrayList<>();
			
			while (eventReader.hasNext()) {
				
				XMLEvent xmlEvent = eventReader.nextEvent();
				if (xmlEvent.isStartElement() &&
						"message".equals(xmlEvent.asStartElement().getName().getLocalPart())) {
					
					inMessageElement = true;
				}
				else if (xmlEvent.isEndElement() && 
						"message".equals(xmlEvent.asEndElement().getName().getLocalPart())) {
					
					inMessageElement = false;
				}
				else if (inMessageElement && xmlEvent.isCharacters()) {
					
					/*String messageValue = xmlEvent.asCharacters().getData().trim();
					customerMessages.add(messageValue);*/
					StringBuilder messageBuilder = new StringBuilder();
					messageBuilder.append(xmlEvent.asCharacters().getData().trim() + " ");
					while (eventReader.peek().isCharacters()) {
						XMLEvent moreCharacters = eventReader.nextEvent();
						messageBuilder.append(moreCharacters.asCharacters().getData().trim() + " ");
					}
					customerMessages.add(messageBuilder.toString().trim());
				}
			}
			
			System.out.println(customerMessages);
		}
		catch (IOException | XMLStreamException ex) {
			ex.printStackTrace(System.err);
		}
	}

}

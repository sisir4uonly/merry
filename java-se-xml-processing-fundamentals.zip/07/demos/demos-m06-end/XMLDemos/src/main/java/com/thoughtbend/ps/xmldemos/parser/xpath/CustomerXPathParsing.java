package com.thoughtbend.ps.xmldemos.parser.xpath;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.thoughtbend.ps.xmldemos.data.Address;
import com.thoughtbend.ps.xmldemos.data.Customer;
import com.thoughtbend.ps.xmldemos.data.ObjectPrinter;
import com.thoughtbend.ps.xmldemos.data.Const;

public class CustomerXPathParsing {

	private static XPathFactory XPATH_FACTORY = XPathFactory.newInstance();
	private static XPath XPATH = XPATH_FACTORY.newXPath();
	
	static {
		
		NamespaceContext customerNamespaceContext = new NamespaceContext() {

			@Override
			public String getNamespaceURI(String prefix) {
				
				String namespace = "";
				
				if ("tbc".equals(prefix)) {
					namespace = Const.Namespace.CUSTOMER;
				}
				else if ("tbad".equals(prefix)) {
					namespace = Const.Namespace.ADDRESS;
				}
				
				return namespace;
			}

			@Override
			public String getPrefix(String namespaceURI) {
				
				String prefix = "";
				
				if (Const.Namespace.CUSTOMER.equals(namespaceURI)) {
					prefix = "tbc";
				}
				else if (Const.Namespace.ADDRESS.equals(namespaceURI)) {
					prefix = "tbad";
				}
				
				return prefix;
			}

			@Override
			public Iterator getPrefixes(String namespaceURI) {
				// We'll ignore this
				return null;
			}
			
		};
		
		XPATH.setNamespaceContext(customerNamespaceContext);
	}
	
	public static void main(String[] args) {
		try (InputStream inputStream = ClassLoader.getSystemResourceAsStream("./customers.xml")) {

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);

			DocumentBuilder builder = factory.newDocumentBuilder();

			Document document = builder.parse(inputStream);

			List<Customer> customerList = new ArrayList<>();

			//NodeList customerNodeList = document.getElementsByTagName("customer");
			
			XPathExpression customersExpression = XPATH.compile("/tbc:customers/tbc:customer");
			NodeList customerNodeList = (NodeList)
					customersExpression.evaluate(document, XPathConstants.NODESET);

			for (int customerIndex = 0; customerIndex < customerNodeList.getLength(); ++customerIndex) {
				
				Node currentCustomerNode = customerNodeList.item(customerIndex);
				customerList.add(buildCustomerFromNode(currentCustomerNode));
				
				XPathExpression addressCountExpression = 
						XPATH.compile("count(tbad:addresses/tbad:address)");
				Number addressCount = (Number)
						addressCountExpression.evaluate(currentCustomerNode, XPathConstants.NUMBER);
				System.out.println("Address count for customer index " + customerIndex + " is " + addressCount);
			}

			for (Customer currentCustomer : customerList) {
				ObjectPrinter.printCustomer(currentCustomer);
			}

		} catch (IOException | ParserConfigurationException | SAXException | XPathExpressionException ex) {
			ex.printStackTrace(System.err);
		}
	}

	private static Customer buildCustomerFromNode(Node customerNode) throws XPathExpressionException {

		Customer newCustomer = new Customer();
		NodeList customerDataNodeList = customerNode.getChildNodes();
		
		XPathFactory xpathFactory = XPathFactory.newInstance();
		XPath xpath = xpathFactory.newXPath();
		
		XPathExpression idExpression = XPATH.compile("@id");
		XPathExpression firstNameExpression = XPATH.compile("tbc:firstName");
		XPathExpression lastNameExpression = XPATH.compile("tbc:lastName");
		XPathExpression emailExpression = XPATH.compile("tbc:email");
		XPathExpression addressesExpression = XPATH.compile("tbad:addresses");
		
		String idValue = (String) idExpression.evaluate(customerNode, XPathConstants.STRING);
		newCustomer.setId(Long.parseLong(idValue));
		
		newCustomer.setFirstName(fetchStringValue(customerNode, firstNameExpression));
		newCustomer.setLastName(fetchStringValue(customerNode, lastNameExpression));
		newCustomer.setEmailAddress(fetchStringValue(customerNode, emailExpression));
		
		Node addressesNode = (Node) addressesExpression.evaluate(customerNode, XPathConstants.NODE);
		
		if (addressesNode != null) {
			
			newCustomer.setAddresses(new ArrayList<>());
			
			NodeList addressNodeList = addressesNode.getChildNodes();
			for (int addressIndex=0; addressIndex < addressNodeList.getLength(); ++addressIndex) {
				
				Node addressNode = addressNodeList.item(addressIndex);
				if (addressNode instanceof Element && "address".equals(addressNode.getLocalName())) {
					
					newCustomer.getAddresses().add(buildAddressFromNode(addressNode));
				}
			}
		}

		return newCustomer;
	}

	private static Address buildAddressFromNode(Node addressNode) throws XPathExpressionException {

		Address address = new Address();
		
		XPathExpression typeExpression = XPATH.compile("tbad:type");
		XPathExpression streetExpression = XPATH.compile("tbad:street");
		XPathExpression cityExpression = XPATH.compile("tbad:city");
		XPathExpression stateExpression = XPATH.compile("tbad:state");
		XPathExpression zipExpression = XPATH.compile("tbad:zip");
		
		address.setAddressType(fetchStringValue(addressNode, typeExpression));
		address.setStreet1(fetchStringValue(addressNode, streetExpression));
		address.setCity(fetchStringValue(addressNode, cityExpression));
		address.setState(fetchStringValue(addressNode, stateExpression));
		address.setZip(fetchStringValue(addressNode, zipExpression));

		return address;
	}
	
	private static String fetchStringValue(Node node, XPathExpression expression) throws XPathExpressionException {
		
		return (String) expression.evaluate(node, XPathConstants.STRING);
	}

}
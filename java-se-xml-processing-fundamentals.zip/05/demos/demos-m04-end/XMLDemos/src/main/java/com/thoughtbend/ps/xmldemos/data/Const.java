package com.thoughtbend.ps.xmldemos.data;

public class Const {

	public static class Namespace {
		public final static String CUSTOMER = "http://www.thoughtbend.com/customer/v1";
		public final static String ADDRESS = "http://www.thoughtbend.com/addr/v1";
	}
}

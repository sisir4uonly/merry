﻿namespace Web.Services
{
    public interface IRolesService
    {
        string[] GetAll();
    }
}
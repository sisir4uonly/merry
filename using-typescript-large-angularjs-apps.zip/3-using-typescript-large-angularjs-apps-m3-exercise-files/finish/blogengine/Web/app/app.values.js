(function () {
    'use strict';
    var currentUser = {
        userId: ''
    };
    angular
        .module('app')
        .value('currentUser', currentUser);
})();
//# sourceMappingURL=app.values.js.map
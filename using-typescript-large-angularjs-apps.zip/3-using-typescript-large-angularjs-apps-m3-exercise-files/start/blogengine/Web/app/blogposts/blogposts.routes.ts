﻿((): void => {
    'use strict';

    angular
        .module('app.blogposts')
        .config(config);

    config.$inject = [
        '$routeProvider',
        '$locationProvider'
    ];
    function config(
        $routeProvider: ng.route.IRouteProvider,
        $locationProvider: ng.ILocationProvider): void {
        $routeProvider
            .when('/admin/blogposts/:id', {
                template: 'BlogPost',
                controller: (): void => {
                },
                controllerAs: 'vm'
            });
    }
})();

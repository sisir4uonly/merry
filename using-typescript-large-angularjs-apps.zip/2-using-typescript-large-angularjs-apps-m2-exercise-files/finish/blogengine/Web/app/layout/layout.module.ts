﻿((): void => {
    'use strict';

    angular
        .module('app.layout', []);
})(); 
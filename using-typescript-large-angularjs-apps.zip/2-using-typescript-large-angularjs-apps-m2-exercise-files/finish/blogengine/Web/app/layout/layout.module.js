(function () {
    'use strict';
    angular
        .module('app.layout', []);
})();
//# sourceMappingURL=layout.module.js.map
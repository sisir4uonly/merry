(function () {
    'use strict';
    angular
        .module('app.usersettings', []);
})();
//# sourceMappingURL=usersettings.module.js.map
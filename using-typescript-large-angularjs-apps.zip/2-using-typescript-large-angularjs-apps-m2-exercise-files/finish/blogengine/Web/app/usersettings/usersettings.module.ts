﻿((): void => {
    'use strict';

    angular
        .module('app.usersettings', []);
})(); 
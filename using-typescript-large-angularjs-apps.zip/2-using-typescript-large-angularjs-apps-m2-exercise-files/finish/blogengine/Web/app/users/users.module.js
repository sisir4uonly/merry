(function () {
    'use strict';
    angular
        .module('app.users', []);
})();
//# sourceMappingURL=users.module.js.map
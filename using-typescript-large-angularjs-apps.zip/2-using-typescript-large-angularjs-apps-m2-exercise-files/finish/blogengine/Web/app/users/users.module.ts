﻿((): void => {
    'use strict';

    angular
        .module('app.users', []);
})(); 
(function () {
    'use strict';
    angular
        .module('app.widgets', []);
})();
//# sourceMappingURL=widgets.module.js.map
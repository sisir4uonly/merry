(function () {
    'use strict';
    angular
        .module('app.blogposts', []);
})();
//# sourceMappingURL=blogposts.module.js.map
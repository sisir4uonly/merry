﻿((): void => {
    'use strict';

    angular
        .module('app.blogposts', []);
})();
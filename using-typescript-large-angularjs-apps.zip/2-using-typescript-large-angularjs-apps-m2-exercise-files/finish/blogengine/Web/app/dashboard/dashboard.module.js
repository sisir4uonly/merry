(function () {
    'use strict';
    angular
        .module('app.dashboard', []);
})();
//# sourceMappingURL=dashboard.module.js.map
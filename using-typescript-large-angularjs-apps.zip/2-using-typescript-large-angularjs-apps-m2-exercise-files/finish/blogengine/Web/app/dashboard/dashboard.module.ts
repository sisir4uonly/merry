﻿((): void => {
    'use strict';

    angular
        .module('app.dashboard', []);
})(); 
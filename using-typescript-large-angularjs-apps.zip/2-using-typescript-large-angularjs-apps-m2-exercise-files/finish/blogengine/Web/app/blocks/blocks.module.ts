﻿((): void => {
    'use strict';

    angular
        .module('app.blocks', []);
})(); 
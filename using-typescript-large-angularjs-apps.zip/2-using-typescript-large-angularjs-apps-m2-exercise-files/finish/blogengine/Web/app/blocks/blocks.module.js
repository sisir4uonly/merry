(function () {
    'use strict';
    angular
        .module('app.blocks', []);
})();
//# sourceMappingURL=blocks.module.js.map
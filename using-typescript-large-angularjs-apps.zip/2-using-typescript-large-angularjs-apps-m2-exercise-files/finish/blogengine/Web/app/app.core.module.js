(function () {
    'use strict';
    angular
        .module('app.core', [
        /*
         * Angular Modules
         */
        'ngRoute',
        'ngSanitize',
        'ngCookies'
    ]);
})();
//# sourceMappingURL=app.core.module.js.map
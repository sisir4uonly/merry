(function () {
    'use strict';
    angular
        .module('app.sitesettings')
        .config(config);
    config.$inject = [
        '$routeProvider',
        '$locationProvider'
    ];
    function config($routeProvider, $locationProvider) {
        $routeProvider
            .when('/admin/sitesettings', {
            template: 'SiteSettings',
            controller: function () {
            },
            controllerAs: 'vm'
        });
    }
})();
//# sourceMappingURL=sitesettings.routes.js.map
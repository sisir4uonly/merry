﻿((): void => {
    'use strict';

    angular
        .module('app.sitesettings', []);
})(); 
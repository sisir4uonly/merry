(function () {
    'use strict';
    angular
        .module('app.sitesettings', []);
})();
//# sourceMappingURL=sitesettings.module.js.map
﻿((): void => {
    'use strict';

    angular
        .module('app.sitesettings')
        .config(config);

    config.$inject = [
        '$routeProvider',
        '$locationProvider'
    ];
    function config(
        $routeProvider: ng.route.IRouteProvider,
        $locationProvider: ng.ILocationProvider): void {
        $routeProvider
            .when('/admin/sitesettings', {
                template: 'SiteSettings',
                controller: (): void => {
                },
                controllerAs: 'vm'
            });
    }
})(); 
(function () {
    'use strict';
    angular
        .module('app.services', []);
})();
//# sourceMappingURL=services.module.js.map
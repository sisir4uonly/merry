#include "foo.h"

int add1(int n)
{
  return n + 1;
}
#pragma once

int add1(int n);
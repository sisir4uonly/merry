// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#define _USE_MATH_DEFINES

#include <array>
#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <fstream>
#include <sstream>

#include <numeric>
#include <cmath>
#include <complex>
#include <random>
#include <ctime>
#include <chrono>
using namespace std;
#pragma once

class EmployeeFactory
{
public:
  Employee make_employee(int id)
  {
    Employee e;
    e.taxId = id;
    return e;
  }
};
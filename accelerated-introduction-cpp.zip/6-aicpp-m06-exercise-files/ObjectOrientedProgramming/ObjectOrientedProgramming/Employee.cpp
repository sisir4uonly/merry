#include "stdafx.h"
#include "Address.h"
#include "Person.h"
#include "Employee.h"

void Employee::greet()
{
  Person::greet();

  cout << "By the way, I work in "
    << department << endl;
}
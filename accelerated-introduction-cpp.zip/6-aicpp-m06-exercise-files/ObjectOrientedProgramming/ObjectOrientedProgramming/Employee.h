#pragma once
#include "Person.h"
class Employee : public Person
{
  friend class EmployeeFactory;

  int taxId;
public:
  Employee()
    : Person(0, "", 0) {}

  Employee(int age, string const& name, int sex,
    string department = string())
    : Person(age, name, sex),
    department(department)
  {}

  void greet() override;

  string department;
};


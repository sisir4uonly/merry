#include "stdafx.h"
#include "Address.h"
#include "Person.h"

Person::Person(int age, string name, int sex)
: age(age), name(name), sex(sex)
{
  address = nullptr;
}

Person::Person(int age, string name, 
  int sex, int house_number, 
  string street_name, string city)
  : Person(age, name, sex)
{
  if (address != nullptr)
    delete address;

  address = new Address(house_number, street_name, city);
}

Person::Person(Person const& p)
: age(p.age), name(p.name), sex(p.sex)
{
  auto* a = p.address;
  address = new Address(
    a->house_number,
    a->street_name,
    a->city);
}

Person::~Person()
{
  if (address != nullptr)
  {
    delete address;
    address = nullptr;
  }
}

void Person::greet()
{
  cout << "My name is " <<
    name << " and I am " <<
    age << " years old." <<
    endl;

  if (address)
  {
    cout << "I live at " <<
      address->house_number << " "
      << address->street_name <<
      ", " << address->city << endl;
  }
}

int Person::getLifeExpectancy()
{
  return lifeExpectancy;
}

int Person::lifeExpectancy = 80;